# Changelog

All notable changes to the Paynecta Payment Gateway for WooCommerce will be documented in this file.

## [1.0.0] - 2025-08-11

### Added
- Initial release of Paynecta Payment Gateway for WooCommerce
- M-Pesa payment integration with STK Push
- WooCommerce Blocks checkout support
- Real-time payment status checking with AJAX polling
- Payment dashboard with transaction statistics
- Transaction reference tracking and display
- M-Pesa receipt number capture and storage
- Webhook support for payment confirmation
- Admin order details enhancement with payment information
- Phone number validation and formatting
- Configurable order status on successful payment
- Clean and responsive payment interface
- Comprehensive error handling and user feedback
- Security features including nonce verification
- Internationalization support (i18n ready)

### Features
- **Payment Processing**: Secure M-Pesa payments via Paynecta API
- **Real-time Updates**: AJAX-powered payment status monitoring
- **Admin Dashboard**: Transaction overview and statistics
- **Order Integration**: Enhanced order details with payment info
- **Block Support**: Compatible with WooCommerce block-based checkout
- **Responsive Design**: Mobile-friendly payment interface
- **Error Handling**: Comprehensive error messages and recovery options
- **Security**: Proper sanitization, validation, and nonce verification

### Technical Details
- WordPress 6.0+ compatibility
- WooCommerce 8.4+ compatibility
- PHP 7.4+ requirement
- Modern JavaScript with ES6+ features
- CSS3 with responsive design
- RESTful API integration
- Webhook callback support
- Database optimization for transaction storage

### Configuration Options
- API URL configuration
- Payment code setup
- API key management
- User email configuration
- Order status customization
- Callback URL display and setup

### Security Features
- Input sanitization and validation
- Output escaping for XSS prevention
- Nonce verification for AJAX requests
- Secure API communication
- Phone number format validation
- Transaction reference verification

### User Experience
- Intuitive payment flow
- Real-time payment feedback
- Mobile-optimized interface
- Clear error messages
- Payment status indicators
- Automatic order updates

### Developer Features
- Clean, documented code
- WordPress coding standards compliance
- Extensible architecture
- Hook and filter support
- Internationalization ready
- Debug logging capabilities
