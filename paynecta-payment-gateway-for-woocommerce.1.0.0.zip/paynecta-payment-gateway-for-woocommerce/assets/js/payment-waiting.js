jQuery(document).ready(function($) {
    // Check if we have the waiting parameters
    if (typeof paynecta_waiting === 'undefined') {
        console.log('Paynecta waiting data not found');
        return;
    }
    
    console.log('Paynecta payment waiting initialized');
    
    // Initialize variables at the top
    let pollCount = 0;
    let pollInterval = null;
    let timeRemaining = 90; // 1:30 minutes in seconds
    let countdownInterval = null;
    let consecutiveErrors = 0;
    const MAX_CONSECUTIVE_ERRORS = 3;
    
    // Start payment waiting process immediately
    showPaymentWaiting();

    function showPaymentWaiting() {
        console.log('Showing payment waiting popup');
        
        const popupHtml = `
            <div class="paynecta-popup-overlay" id="paynecta-popup">
                <div class="paynecta-popup">
                    <div class="paynecta-logo">P</div>
                    <h2>${paynecta_waiting.messages.waiting_title}</h2>
                    <div class="paynecta-spinner"></div>
                    <p>${paynecta_waiting.messages.waiting_text}</p>
                    <div class="paynecta-payment-details">
                        <p><strong>Phone:</strong> ${paynecta_waiting.phone_number}</p>
                        <p><strong>Amount:</strong> ${paynecta_waiting.amount}</p>
                    </div>
                    <div class="paynecta-countdown">
                        <p>Time remaining: <span id="countdown-timer">1:30</span></p>
                    </div>
                    <div class="paynecta-popup-buttons">
                        <button class="paynecta-btn paynecta-btn-secondary" onclick="cancelPayment()">
                            ${paynecta_waiting.messages.cancel_payment}
                        </button>
                    </div>
                </div>
            </div>
        `;
        
        // Remove any existing popup first
        $('#paynecta-popup').remove();
        
        // Add popup to body
        $('body').append(popupHtml);
        
        console.log('Popup added to DOM');
        
        // Start countdown timer
        startCountdown();
        
        // Start polling for payment status
        startStatusPolling();
    }

    function startCountdown() {
        countdownInterval = setInterval(function() {
            timeRemaining--;
            const minutes = Math.floor(timeRemaining / 60);
            const seconds = timeRemaining % 60;
            const timeString = minutes + ':' + (seconds < 10 ? '0' : '') + seconds;
            
            $('#countdown-timer').text(timeString);
            
            if (timeRemaining <= 0) {
                clearInterval(countdownInterval);
            }
        }, 1000);
    }

    function startStatusPolling() {
        console.log('Starting status polling');
        
        // Poll immediately, then every 5 seconds
        checkPaymentStatus();
        
        pollInterval = setInterval(function() {
            checkPaymentStatus();
        }, paynecta_waiting.poll_interval);
    }

    function stopStatusPolling() {
        console.log('Stopping status polling');
        if (pollInterval) {
            clearInterval(pollInterval);
            pollInterval = null;
        }
        if (countdownInterval) {
            clearInterval(countdownInterval);
            countdownInterval = null;
        }
    }

    function checkPaymentStatus() {
        pollCount++;
        console.log('Checking payment status, poll count:', pollCount);
        
        // Stop polling after max attempts (1:30 minutes)
        if (pollCount >= paynecta_waiting.max_polls) {
            console.log('Max polls reached, showing timeout');
            stopStatusPolling();
            showTimeoutMessage();
            return;
        }

        $.ajax({
            url: paynecta_waiting.ajax_url,
            type: 'POST',
            data: {
                action: 'paynecta_check_status',
                nonce: paynecta_waiting.nonce,
                transaction_reference: paynecta_waiting.transaction_ref,
                order_id: paynecta_waiting.order_id
            },
            beforeSend: function() {
                console.log('=== AJAX Request ===');
                console.log('URL:', paynecta_waiting.ajax_url);
                console.log('Transaction Ref:', paynecta_waiting.transaction_ref);
                console.log('Order ID:', paynecta_waiting.order_id);
            },
            success: function(response) {
                console.log('=== AJAX Response ===');
                console.log('Full response:', JSON.stringify(response, null, 2));
                console.log('Success:', response.success);
                console.log('Data:', response.data);

                if (response.success) {
                    // Reset error counter on successful response
                    consecutiveErrors = 0;

                    const status = response.data.status;
                    console.log('Payment status:', status);
                    console.log('Status label:', response.data.status_label);
                    console.log('M-Pesa Receipt:', response.data.mpesa_receipt);

                    if (status === 'completed') {
                        stopStatusPolling();
                        showSuccessMessage(response.data);
                    } else if (status === 'cancelled') {
                        stopStatusPolling();
                        showCancelledMessage();
                    } else if (status === 'failed') {
                        stopStatusPolling();
                        showFailedMessage();
                    }
                    // Continue polling for pending status
                } else {
                    // Handle error response from server
                    consecutiveErrors++;
                    const errorMessage = response.data ? response.data.message : 'Unknown error occurred';
                    const errorCode = response.data ? response.data.error_code : 'unknown';
                    const canRetry = response.data ? response.data.can_retry : true;

                    console.log('=== Status Check Error ===');
                    console.log('Error Message:', errorMessage);
                    console.log('Error Code:', errorCode);
                    console.log('Consecutive errors:', consecutiveErrors);

                    // Show error to user after multiple consecutive failures
                    if (consecutiveErrors >= MAX_CONSECUTIVE_ERRORS) {
                        stopStatusPolling();
                        showErrorMessage(errorMessage, canRetry);
                    } else {
                        // Show temporary error indicator but continue polling
                        showTemporaryError(errorMessage);
                    }
                }
            },
            error: function(xhr, status, error) {
                console.log('=== AJAX Error ===');
                console.log('XHR Status:', xhr.status);
                console.log('XHR Response:', xhr.responseText);
                console.log('Status:', status);
                console.log('Error:', error);
                consecutiveErrors++;

                let errorMessage = 'Network error. Please check your internet connection.';

                if (xhr.status === 0) {
                    errorMessage = 'Unable to connect to server. Please check your internet connection.';
                } else if (xhr.status === 500) {
                    errorMessage = 'Server error occurred. Please try again.';
                    console.log('500 Error Response Body:', xhr.responseText);
                } else if (xhr.status === 403) {
                    errorMessage = 'Access denied. Please refresh the page and try again.';
                } else if (status === 'timeout') {
                    errorMessage = 'Request timed out. Please wait...';
                }

                console.log('Consecutive errors:', consecutiveErrors);

                // Show error to user after multiple consecutive failures
                if (consecutiveErrors >= MAX_CONSECUTIVE_ERRORS) {
                    stopStatusPolling();
                    showErrorMessage(errorMessage, true);
                } else {
                    showTemporaryError(errorMessage);
                }
            }
        });
    }

    function showSuccessMessage(data) {
        console.log('Showing success message');
        updatePopup(`
            <div class="paynecta-logo">P</div>
            <h2>${paynecta_waiting.messages.success_title}</h2>
            <div class="paynecta-icon paynecta-icon-success">✓</div>
            <p>${paynecta_waiting.messages.success_text}</p>
            <div class="paynecta-payment-details">
                <p><strong>Amount:</strong> ${data.amount || paynecta_waiting.amount}</p>
                <p><strong>M-Pesa Receipt:</strong> ${data.mpesa_receipt || 'N/A'}</p>
            </div>
            <div class="paynecta-popup-buttons">
                <button class="paynecta-btn paynecta-btn-success" onclick="goToOrder()">
                    ${paynecta_waiting.messages.view_order}
                </button>
            </div>
        `);
    }

    function showCancelledMessage() {
        console.log('Showing cancelled message');
        updatePopup(`
            <div class="paynecta-logo">P</div>
            <h2>${paynecta_waiting.messages.cancelled_title}</h2>
            <div class="paynecta-icon paynecta-icon-warning">⚠</div>
            <p>${paynecta_waiting.messages.cancelled_text}</p>
            <div class="paynecta-popup-buttons">
                <button class="paynecta-btn paynecta-btn-primary" onclick="tryAgain()">
                    ${paynecta_waiting.messages.try_again}
                </button>
                <button class="paynecta-btn paynecta-btn-secondary" onclick="goToOrder()">
                    ${paynecta_waiting.messages.view_order}
                </button>
            </div>
        `);
    }

    function showFailedMessage() {
        console.log('Showing failed message');
        updatePopup(`
            <div class="paynecta-logo">P</div>
            <h2>${paynecta_waiting.messages.failed_title}</h2>
            <div class="paynecta-icon paynecta-icon-error">✗</div>
            <p>${paynecta_waiting.messages.failed_text}</p>
            <div class="paynecta-popup-buttons">
                <button class="paynecta-btn paynecta-btn-primary" onclick="tryAgain()">
                    ${paynecta_waiting.messages.try_again}
                </button>
                <button class="paynecta-btn paynecta-btn-secondary" onclick="goToOrder()">
                    ${paynecta_waiting.messages.view_order}
                </button>
            </div>
        `);
    }

    function showTimeoutMessage() {
        console.log('Showing timeout message');
        updatePopup(`
            <div class="paynecta-logo">P</div>
            <h2>${paynecta_waiting.messages.timeout_title}</h2>
            <div class="paynecta-icon paynecta-icon-warning">⏰</div>
            <p>${paynecta_waiting.messages.timeout_text}</p>
            <div class="paynecta-popup-buttons">
                <button class="paynecta-btn paynecta-btn-primary" onclick="tryAgain()">
                    ${paynecta_waiting.messages.try_again}
                </button>
                <button class="paynecta-btn paynecta-btn-secondary" onclick="goToOrder()">
                    ${paynecta_waiting.messages.view_order}
                </button>
            </div>
        `);
    }

    function showErrorMessage(errorMessage, canRetry) {
        console.log('Showing error message:', errorMessage);
        updatePopup(`
            <div class="paynecta-logo">P</div>
            <h2>Error</h2>
            <div class="paynecta-icon paynecta-icon-error">!</div>
            <p>${escapeHtml(errorMessage)}</p>
            <div class="paynecta-payment-details" style="background: #ffeaea; border-left-color: #e74c3c;">
                <p style="color: #c0392b; margin: 0;"><strong>What happened?</strong> We couldn't verify your payment status. Your payment may still be processing.</p>
            </div>
            <div class="paynecta-popup-buttons">
                ${canRetry ? `<button class="paynecta-btn paynecta-btn-primary" onclick="retryStatusCheck()">
                    Retry
                </button>` : ''}
                <button class="paynecta-btn paynecta-btn-warning" onclick="tryAgain()">
                    ${paynecta_waiting.messages.try_again}
                </button>
                <button class="paynecta-btn paynecta-btn-secondary" onclick="goToOrder()">
                    ${paynecta_waiting.messages.view_order}
                </button>
            </div>
        `);
    }

    function showTemporaryError(errorMessage) {
        // Show a small error indicator without stopping the polling
        let errorBanner = $('#paynecta-error-banner');
        if (errorBanner.length === 0) {
            $('.paynecta-popup').append('<div id="paynecta-error-banner" style="background: #fff3cd; color: #856404; padding: 10px; border-radius: 5px; margin-top: 15px; font-size: 13px;"></div>');
            errorBanner = $('#paynecta-error-banner');
        }
        errorBanner.html('<strong>Warning:</strong> ' + escapeHtml(errorMessage) + ' Retrying...');

        // Remove the banner after 4 seconds
        setTimeout(function() {
            errorBanner.fadeOut(300, function() {
                $(this).remove();
            });
        }, 4000);
    }

    function escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    function updatePopup(content) {
        $('.paynecta-popup').html(content);
    }

    function closePopup() {
        stopStatusPolling();
        $('#paynecta-popup').remove();
    }

    // Global functions for button clicks
    window.cancelPayment = function() {
        console.log('Cancel payment clicked');
        closePopup();
        window.location.href = paynecta_waiting.checkout_url;
    };

    window.tryAgain = function() {
        console.log('Try again clicked');
        closePopup();
        window.location.href = paynecta_waiting.checkout_url;
    };

    window.goToOrder = function() {
        console.log('Go to order clicked');
        closePopup();
        window.location.href = paynecta_waiting.order_url;
    };

    window.retryStatusCheck = function() {
        console.log('Retry status check clicked');
        // Reset error counter and restart polling
        consecutiveErrors = 0;
        pollCount = 0;
        timeRemaining = 90;
        showPaymentWaiting();
    };

    // Prevent closing popup by clicking outside or pressing escape
    $(document).on('click', '.paynecta-popup-overlay', function(e) {
        if (e.target === this) {
            // Don't close - user must use buttons
            return false;
        }
    });

    $(document).on('keydown', function(e) {
        if (e.key === 'Escape') {
            // Don't close - user must use buttons
            return false;
        }
    });
});
