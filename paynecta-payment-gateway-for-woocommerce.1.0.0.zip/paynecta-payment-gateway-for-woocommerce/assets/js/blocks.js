const { createElement, useState, useEffect } = window.wp.element;
const { __ } = window.wp.i18n;

const settings = window.wc.wcSettings.getSetting('paynecta_data', {});
const label = window.wp.htmlEntities.decodeEntities(settings.title) || 'Paynecta Payment';

const Content = (props) => {
    const [phoneNumber, setPhoneNumber] = useState('');
    
    const { eventRegistration, emitResponse } = props;
    const { onPaymentSetup } = eventRegistration;
    
    // Register payment setup handler
    useEffect(() => {
        const unsubscribe = onPaymentSetup(async () => {
            if (!phoneNumber) {
                return {
                    type: emitResponse.responseTypes.ERROR,
                    message: __('M-Pesa phone number is required.', 'paynecta-payment-gateway'),
                };
            }
            
            return {
                type: emitResponse.responseTypes.SUCCESS,
                meta: {
                    paymentMethodData: {
                        paynecta_phone_number: phoneNumber,
                    },
                },
            };
        });
        
        return () => {
            unsubscribe();
        };
    }, [onPaymentSetup, phoneNumber, emitResponse]);

    return createElement('div', { className: 'paynecta-payment-fields' }, [
        createElement('p', { key: 'description' }, 
            window.wp.htmlEntities.decodeEntities(settings.description || '')
        ),
        createElement('div', { key: 'phone-field', className: 'form-row form-row-wide' }, [
            createElement('label', { 
                key: 'label',
                htmlFor: 'paynecta-phone-number',
                style: { display: 'block', marginBottom: '5px', fontWeight: 'bold' }
            }, [
                __('M-Pesa Phone Number', 'paynecta-payment-gateway'),
                createElement('span', { 
                    key: 'required',
                    style: { color: '#e74c3c' }
                }, ' *')
            ]),
            createElement('input', {
                key: 'input',
                type: 'tel',
                id: 'paynecta-phone-number',
                placeholder: __('e.g. 0712345678 or 254712345678', 'paynecta-payment-gateway'),
                value: phoneNumber,
                onChange: (e) => setPhoneNumber(e.target.value),
                className: 'input-text',
                style: { width: '100%' },
                required: true
            }),
            createElement('small', {
                key: 'help',
                style: { color: '#666', fontSize: '12px', display: 'block', marginTop: '5px' }
            }, __('Enter your Safaricom M-Pesa number to receive payment prompt', 'paynecta-payment-gateway'))
        ])
    ]);
};

const iconSrc = settings.icon;

const iconElement = iconSrc ? createElement('img', { 
    src: iconSrc, 
    alt: 'Paynecta', 
    style: { width: '32px', marginRight: '10px', verticalAlign: 'middle' } 
}) : null;

// Create a label element that includes the icon and text
const labelElement = createElement('span', { style: { display: 'flex', alignItems: 'center' } }, [
    iconElement,
    label
]);

const Block_Gateway = {
    name: 'paynecta',
    label: labelElement, // Use the proper element with icon
    content: createElement(Content),
    edit: createElement(Content),
    canMakePayment: () => true,
    ariaLabel: label,
    supports: {
        features: settings.supports,
    },
};

window.wc.wcBlocksRegistry.registerPaymentMethod(Block_Gateway);
