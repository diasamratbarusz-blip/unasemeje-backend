<?php
use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Paynecta Blocks integration
 *
 * @since 1.0.0
 */
final class Paynecta_Blocks_Integration extends AbstractPaymentMethodType {
    /**
     * The gateway instance.
     *
     * @var Paynecta_Gateway
     */
    private $gateway;

    /**
     * Payment method name/id.
     *
     * @var string
     */
    protected $name = 'paynecta';

    /**
     * Initializes the payment method type.
     */
    public function initialize() {
        $this->settings = get_option('woocommerce_paynecta_settings', []);
        $this->gateway = new Paynecta_Gateway();
        
        // Hook to process payment method data from block checkout
        add_action('woocommerce_rest_checkout_process_payment_with_context', [$this, 'process_payment_method_data_hook'], 10, 2);
    }

    /**
     * Returns if this payment method should be active.
     *
     * @return boolean
     */
    public function is_active() {
        return $this->gateway->is_available();
    }

    /**
     * Returns an array of scripts/handles to be registered for this payment method.
     *
     * @return array
     */
    public function get_payment_method_script_handles() {
        wp_register_script(
            'paynecta-blocks',
            plugin_dir_url(__FILE__) . 'assets/js/blocks.js',
            [
                'wc-blocks-registry',
                'wc-settings',
                'wp-element',
                'wp-html-entities',
                'wp-i18n',
            ],
            '1.0.0',
            true
        );
        return ['paynecta-blocks'];
    }

    /**
     * Returns an array of key=>value pairs representing the actual data
     * of this payment method that will be available on the frontend.
     *
     * @return array
     */
    public function get_payment_method_data() {
        return [
            'title' => $this->gateway->get_option('title'),
            'description' => $this->gateway->get_option('description'),
            'supports' => array_filter($this->gateway->supports, [$this->gateway, 'supports']),
            'icon' => $this->gateway->icon, // Pass the raw URL
            'has_fields' => true,
        ];
    }

    /**
     * Process payment method data from the block checkout
     */
    public function process_payment_method_data($payment_method_data) {
        if (isset($payment_method_data['paynecta_phone_number'])) {
            $_POST['paynecta_phone_number'] = sanitize_text_field($payment_method_data['paynecta_phone_number']);
        }
    }

    /**
     * Hook method to process payment method data from block checkout
     */
    public function process_payment_method_data_hook($context, $result) {
        if ($context->payment_method === $this->name && isset($context->payment_data['payment_method_data'])) {
            $this->process_payment_method_data($context->payment_data['payment_method_data']);
        }
    }
}
