<?php
/*
 * Plugin Name: Paynecta Payment Gateway for WooCommerce
 * Description: Send a payment link, clients pay via M-Pesa and funds go directly to any Kenyan bank of your choice. All payments automatically reconciled. Visit https://paynecta.co.ke/ for more information.
 * Version: 1.0.0
 * Author: Paynecta
 * Author URI: https://paynecta.co.ke/
 * License: GPL-2.0+
 * Text Domain: paynecta-payment-gateway-for-woocommerce
 * Domain Path: /languages
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Requires Plugins: woocommerce
 * WC requires at least: 8.4
 * WC tested up to: 9.3
 */

if (!defined('ABSPATH')) {
    exit;
}

add_action('before_woocommerce_init', function() {
    if (class_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil')) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('custom_order_tables', __FILE__, true);
    }
});

add_action('woocommerce_loaded', 'paynecta_init_payment_gateway');

function paynecta_init_payment_gateway() {
    if (!class_exists('WC_Payment_Gateway')) {
        return;
    }

    if (class_exists('Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType')) {
        require_once plugin_dir_path(__FILE__) . 'class-paynecta-blocks.php';
    }

    class Paynecta_Gateway extends WC_Payment_Gateway {
        public function __construct() {
            $this->id = 'paynecta';
            $this->has_fields = true;
            $this->method_title = __('Paynecta Payment Gateway', 'paynecta-payment-gateway-for-woocommerce');
            $this->method_description = __('Send a payment link, clients pay via M-Pesa and funds go directly to any Kenyan bank of your choice. All payments automatically reconciled.', 'paynecta-payment-gateway-for-woocommerce');
            $this->icon = plugin_dir_url(__FILE__) . 'assets/images/paynecta-icon.png';
            $this->supports = ['products'];

            $this->init_form_fields();
            $this->init_settings();

            $this->enabled = $this->get_option('enabled');
            $this->title = $this->get_option('title');
            $this->description = $this->get_option('description');
            $this->api_url = $this->get_option('api_url');
            $this->payment_code = $this->get_option('payment_code');
            $this->api_key = $this->get_option('api_key');
            $this->user_email = $this->get_option('user_email');
            $this->order_status_on_payment = $this->get_option('order_status_on_payment', 'processing');

            add_action("woocommerce_update_options_payment_gateways_{$this->id}", [$this, 'process_admin_options']);
            add_action('woocommerce_api_paynecta', [$this, 'handle_webhook_callback']);
            add_action('wp_ajax_paynecta_check_status', [$this, 'ajax_check_payment_status']);
            add_action('wp_ajax_nopriv_paynecta_check_status', [$this, 'ajax_check_payment_status']);
            add_action('wp', [$this, 'handle_payment_waiting_page']);
            add_action('admin_menu', [$this, 'add_admin_menu']);
            add_action('woocommerce_admin_order_data_after_billing_address', [$this, 'display_transaction_reference_in_admin']);
            add_action('woocommerce_admin_order_data_after_order_details', [$this, 'display_paynecta_payment_details']);
            
            // Enqueue scripts and styles
            add_action('wp_enqueue_scripts', [$this, 'enqueue_styles']);
            add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_styles']);
        }

        public function enqueue_styles() {
            if (is_checkout()) {
                wp_enqueue_style('paynecta-checkout', plugin_dir_url(__FILE__) . 'assets/css/paynecta-checkout.css', [], '1.0.0');
            }
        }

        public function enqueue_admin_styles() {
            if (isset($_GET['page']) && $_GET['page'] === 'paynecta-dashboard') {
                wp_enqueue_style('paynecta-admin', plugin_dir_url(__FILE__) . 'assets/css/paynecta-admin.css', [], '1.0.0');
            }
        }

        /**
         * Log error messages for debugging
         */
        private function log_error($message, $context = []) {
            if (class_exists('WC_Logger')) {
                wc_get_logger()->error($message, array_merge(['source' => 'paynecta'], $context));
            }
        }

        /**
         * Log informational messages for debugging
         */
        private function log_info($message, $context = []) {
            // Only log info if debug mode is enabled to reduce noise
            if (defined('WP_DEBUG') && WP_DEBUG && class_exists('WC_Logger')) {
                wc_get_logger()->info($message, array_merge(['source' => 'paynecta'], $context));
            }
        }

        public function is_available() {
            if ('yes' !== $this->enabled) {
                return false;
            }

            if (!class_exists('WooCommerce')) {
                return false;
            }

            return parent::is_available();
        }

        public function payment_fields() {
            if ($this->description) {
                echo '<p>' . wp_kses_post($this->description) . '</p>';
            }

            $billing_phone = '';
            if (WC()->customer) {
                $billing_phone = WC()->customer->get_billing_phone();
            }

            echo '<div class="paynecta-payment-fields">';
            echo '<p class="form-row form-row-wide">';
            echo '<label for="paynecta_phone_number">' . esc_html__('M-Pesa Phone Number', 'paynecta-payment-gateway-for-woocommerce') . ' <span class="required">*</span></label>';
            echo '<input type="tel" id="paynecta_phone_number" name="paynecta_phone_number" class="input-text" ';
            echo 'placeholder="' . esc_attr__('e.g. 0712345678 or 254712345678', 'paynecta-payment-gateway-for-woocommerce') . '" ';
            echo 'value="' . esc_attr($billing_phone) . '" required />';
            echo '<small>' . esc_html__('Enter your Safaricom M-Pesa number to receive payment prompt', 'paynecta-payment-gateway-for-woocommerce') . '</small>';
            echo '</p>';
            echo '</div>';

            echo '</div>';
        }

        public function validate_fields() {
            // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified by WooCommerce checkout
            $phone_number = isset($_POST['paynecta_phone_number']) ? sanitize_text_field(wp_unslash($_POST['paynecta_phone_number'])) : '';

            if (empty($phone_number)) {
                wc_add_notice(__('M-Pesa phone number is required.', 'paynecta-payment-gateway-for-woocommerce'), 'error');
                return false;
            }

            $formatted_phone = $this->format_phone_number($phone_number);
            if (!$formatted_phone) {
                wc_add_notice(__('Please enter a valid Safaricom M-Pesa phone number (e.g., 0712345678 or 254712345678).', 'paynecta-payment-gateway-for-woocommerce'), 'error');
                return false;
            }

            return true;
        }

        public function init_form_fields() {
            $this->form_fields = [
                'enabled' => [
                    'title' => __('Enable/Disable', 'paynecta-payment-gateway-for-woocommerce'),
                    'type' => 'checkbox',
                    'label' => __('Enable Paynecta Payment Gateway', 'paynecta-payment-gateway-for-woocommerce'),
                    'default' => 'yes'
                ],
                'title' => [
                    'title' => __('Title', 'paynecta-payment-gateway-for-woocommerce'),
                    'type' => 'text',
                    'description' => __('The title displayed to customers during checkout.', 'paynecta-payment-gateway-for-woocommerce'),
                    'default' => __('Paynecta Payment', 'paynecta-payment-gateway-for-woocommerce'),
                    'desc_tip' => true
                ],
                'description' => [
                    'title' => __('Description', 'paynecta-payment-gateway-for-woocommerce'),
                    'type' => 'textarea',
                    'description' => __('The description displayed to customers during checkout.', 'paynecta-payment-gateway-for-woocommerce'),
                    'default' => __('Pay securely via M-Pesa through Paynecta. Funds go directly to your bank account.', 'paynecta-payment-gateway-for-woocommerce')
                ],
                'api_url' => [
                    'title' => __('API URL', 'paynecta-payment-gateway-for-woocommerce'),
                    'type' => 'text',
                    'description' => __('The Paynecta API URL for processing payments.', 'paynecta-payment-gateway-for-woocommerce'),
                    'default' => 'https://paynecta.co.ke/api/v1',
                    'desc_tip' => true
                ],
                'api_key' => [
                    'title' => __('API Key', 'paynecta-payment-gateway-for-woocommerce'),
                    'type' => 'password',
                    'description' => __('Your Paynecta API Key.', 'paynecta-payment-gateway-for-woocommerce'),
                    'default' => '',
                    'desc_tip' => true
                ],
                'user_email' => [
                    'title' => __('User Email', 'paynecta-payment-gateway-for-woocommerce'),
                    'type' => 'email',
                    'description' => __('Your Paynecta account email address.', 'paynecta-payment-gateway-for-woocommerce'),
                    'default' => '',
                    'desc_tip' => true
                ],
                'payment_code' => [
                    'title' => __('Payment Link', 'paynecta-payment-gateway-for-woocommerce'),
                    'type' => 'select',
                    'description' => __('Select your Paynecta Payment Link. If empty, please save your API Key and Email first.', 'paynecta-payment-gateway-for-woocommerce'),
                    'default' => '',
                    'options' => $this->get_paynecta_links(),
                    'desc_tip' => true
                ],
                'order_status_on_payment' => [
                    'title' => __('Order Status on Payment', 'paynecta-payment-gateway-for-woocommerce'),
                    'type' => 'select',
                    'description' => __('Select the order status to set when payment is received successfully.', 'paynecta-payment-gateway-for-woocommerce'),
                    'default' => 'processing',
                    'options' => [
                        'processing' => __('Processing', 'paynecta-payment-gateway-for-woocommerce'),
                        'completed' => __('Completed', 'paynecta-payment-gateway-for-woocommerce'),
                        'on-hold' => __('On Hold', 'paynecta-payment-gateway-for-woocommerce')
                    ],
                    'desc_tip' => true
                ],
                'callback_url_display' => [
                    'title' => __('Callback URL', 'paynecta-payment-gateway-for-woocommerce'),
                    'type' => 'callback_url_display',
                    'description' => __('Copy the above URL and set it as your callback URL in your Paynecta account settings.', 'paynecta-payment-gateway-for-woocommerce'),
                ],
            ];
        }

        /**
         * Fetch Paynecta Payment Links from API
         */
        private function get_paynecta_links() {
            $options = ['' => __('Select a Payment Link', 'paynecta-payment-gateway-for-woocommerce')];
            
            $api_url = $this->get_option('api_url');
            $api_key = $this->get_option('api_key');
            $user_email = $this->get_option('user_email');
            
            if (empty($api_key) || empty($user_email)) {
                return ['' => __('Enter API Key & Email, then save to load links', 'paynecta-payment-gateway-for-woocommerce')];
            }
            
            // Check transient first
            $cached_links = get_transient('paynecta_payment_links_' . md5($api_key));
            if ($cached_links !== false) {
                return $cached_links;
            }
            
            $endpoint = rtrim($api_url, '/') . '/links';
            
            $response = wp_remote_get($endpoint, [
                'headers' => [
                    'X-API-Key' => $api_key,
                    'X-User-Email' => $user_email,
                    'Accept' => 'application/json'
                ],
                'timeout' => 15
            ]);
            
            if (is_wp_error($response)) {
                /* translators: %s: Error message from API */
                return ['' => sprintf(__('Error fetching links: %s', 'paynecta-payment-gateway-for-woocommerce'), $response->get_error_message())];
            }
            
            $body = wp_remote_retrieve_body($response);
            $data = json_decode($body, true);
            
            if (isset($data['success']) && $data['success'] === true && isset($data['data']['links'])) {
                foreach ($data['data']['links'] as $link) {
                    if (isset($link['unique_code']) && isset($link['name'])) {
                        $label = sprintf('%s (%s)', $link['name'], $link['unique_code']);
                        if (isset($link['display_name']) && !empty($link['display_name'])) {
                             $label .= ' - ' . $link['display_name'];
                        }
                        $options[$link['unique_code']] = $label;
                    }
                }
                
                // Cache for 1 hour
                set_transient('paynecta_payment_links_' . md5($api_key), $options, HOUR_IN_SECONDS);
            } else {
                 $options[''] = __('No links found or invalid API key', 'paynecta-payment-gateway-for-woocommerce');
                 // If API key is invalid, maybe clear cached invalid response quickly? No need.
            }
            
            return $options;
        }

        /**
         * Clear cached links when options are saved
         */
        public function process_admin_options() {
            $saved = parent::process_admin_options();
            // Clear cache to force refresh on next load
            $api_key = $this->get_option('api_key');
            if ($api_key) {
                delete_transient('paynecta_payment_links_' . md5($api_key));
            }
            return $saved;
        }

        public function generate_callback_url_display_html($key, $field) {
            $callback_url = WC()->api_request_url('paynecta');
            $description = $field['description'] ?? '';

            $html = '<tr valign="top">';
            $html .= '<th scope="row" class="titledesc">';
            $html .= '<label>' . esc_html($field['title']) . '</label>';
            $html .= '</th>';
            $html .= '<td class="forminp">';
            $html .= '<h3 class="alert alert-info"><b>' . esc_html($callback_url) . '</b></h3>';
            $html .= '<p class="description">' . esc_html($description) . '</p>';
            $html .= '</td>';
            $html .= '</tr>';

            return $html;
        }

        public function process_payment($order_id) {
            $order = wc_get_order($order_id);

            if (!$order) {
                wc_add_notice(__('Order not found.', 'paynecta-payment-gateway-for-woocommerce'), 'error');
                return ['result' => 'failure'];
            }

            $order->update_status('pending', __('Awaiting payment via Paynecta STK Push.', 'paynecta-payment-gateway-for-woocommerce'));

            $api_url = $this->get_option('api_url');
            $payment_code = $this->get_option('payment_code');
            $api_key = $this->get_option('api_key');
            $user_email = $this->get_option('user_email');

            if (empty($api_url) || empty($payment_code) || empty($api_key) || empty($user_email)) {
                wc_add_notice(__('Paynecta payment gateway is not fully configured. Please contact the store administrator.', 'paynecta-payment-gateway-for-woocommerce'), 'error');
                return ['result' => 'failure'];
            }

            // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified by WooCommerce checkout
            $phone_number = isset($_POST['paynecta_phone_number']) ? sanitize_text_field(wp_unslash($_POST['paynecta_phone_number'])) : '';
            
            if (empty($phone_number)) {
                wc_add_notice(__('M-Pesa phone number is required.', 'paynecta-payment-gateway-for-woocommerce'), 'error');
                return ['result' => 'failure'];
            }

            $phone = $this->format_phone_number($phone_number);
            if (!$phone) {
                wc_add_notice(__('Please provide a valid Safaricom phone number.', 'paynecta-payment-gateway-for-woocommerce'), 'error');
                return ['result' => 'failure'];
            }

            $stk_result = $this->initiate_stk_push($payment_code, $phone, $order->get_total(), $api_key, $user_email, $order_id);

            if (!$stk_result || !isset($stk_result['success']) || $stk_result['success'] !== true) {
                $error_message = isset($stk_result['error']) ? $stk_result['error'] : __('Unable to initiate payment. Please try again.', 'paynecta-payment-gateway-for-woocommerce');
                wc_add_notice($error_message, 'error');
                /* translators: %s: Error message from payment initiation */
                $order->add_order_note(sprintf(__('Payment initiation failed: %s', 'paynecta-payment-gateway-for-woocommerce'), $error_message));
                return ['result' => 'failure'];
            }

            if (!isset($stk_result['transaction_reference'])) {
                wc_add_notice(__('Payment server did not return a transaction reference. Please try again.', 'paynecta-payment-gateway-for-woocommerce'), 'error');
                return ['result' => 'failure'];
            }

            $transaction_reference = $stk_result['transaction_reference'];

            $order->update_meta_data('_paynecta_transaction_reference', $transaction_reference);
            $order->update_meta_data('_paynecta_phone_number', $phone);
            $order->save();

            $order->update_status('pending', __('STK Push initiated. Waiting for customer to complete payment on phone.', 'paynecta-payment-gateway-for-woocommerce'));
            /* translators: 1: Phone number, 2: Transaction Reference */
            $order->add_order_note(sprintf(__('STK Push sent to %1$s. Transaction Reference: %2$s', 'paynecta-payment-gateway-for-woocommerce'), $phone, $transaction_reference));

            return [
                'result' => 'success',
                'redirect' => add_query_arg([
                    'paynecta_wait' => '1',
                    'order_id' => $order_id,
                    'transaction_ref' => $transaction_reference,
                    'key' => $order->get_order_key()
                ], wc_get_checkout_url())
            ];
        }

        private function format_phone_number($phone) {
            $phone = preg_replace('/[^0-9]/', '', $phone);
            
            if (strlen($phone) == 10 && substr($phone, 0, 1) == '0') {
                return '254' . substr($phone, 1);
            } elseif (strlen($phone) == 9) {
                return '254' . $phone;
            } elseif (strlen($phone) == 12 && substr($phone, 0, 3) == '254') {
                return $phone;
            }
            
            return false;
        }

        private function initiate_stk_push($payment_code, $phone, $amount, $api_key, $user_email, $order_id) {
            $api_url = $this->get_option('api_url');
            $endpoint = rtrim($api_url, '/') . '/payment/initialize';

            $headers = [
                'Content-Type' => 'application/json',
                'X-API-Key' => $api_key,
                'X-User-Email' => $user_email,
                'Accept' => 'application/json'
            ];

            $body_data = [
                'code' => $payment_code,
                'mobile_number' => $phone,
                'amount' => (int)$amount
            ];

            $response = wp_remote_post($endpoint, [
                'headers' => $headers,
                'body' => json_encode($body_data),
                'timeout' => 30
            ]);

            // Handle WP_Error (network failures, timeouts, etc.)
            if (is_wp_error($response)) {
                $error_message = $response->get_error_message();
                $this->log_error('STK Push network error', [
                    'order_id' => $order_id,
                    'endpoint' => $endpoint,
                    'error' => $error_message
                ]);
                return [
                    'success' => false,
                    /* translators: %s: Error message from network */
                    'error' => sprintf(__('Connection error: %s', 'paynecta-payment-gateway-for-woocommerce'), $error_message)
                ];
            }

            // Check HTTP status code
            $http_code = wp_remote_retrieve_response_code($response);
            $body = wp_remote_retrieve_body($response);

            // Handle non-200 HTTP responses
            if ($http_code < 200 || $http_code >= 300) {
                $this->log_error('STK Push HTTP error', [
                    'order_id' => $order_id,
                    'http_code' => $http_code,
                    'response_body' => $body
                ]);
                return [
                    'success' => false,
                    /* translators: %d: HTTP status code */
                    'error' => sprintf(__('API error (HTTP %d): Please check your API credentials or contact support.', 'paynecta-payment-gateway-for-woocommerce'), $http_code)
                ];
            }

            // Handle JSON decode failures
            $data = json_decode($body, true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                $this->log_error('STK Push JSON decode error', [
                    'order_id' => $order_id,
                    'json_error' => json_last_error_msg(),
                    'response_body' => substr($body, 0, 500)
                ]);
                return [
                    'success' => false,
                    'error' => __('Invalid response from payment server. Please try again.', 'paynecta-payment-gateway-for-woocommerce')
                ];
            }

            // Check for successful response
            if (isset($data['success']) && $data['success'] === true && isset($data['data']['transaction_reference'])) {
                $this->log_info('STK Push initiated successfully', [
                    'order_id' => $order_id,
                    'transaction_reference' => $data['data']['transaction_reference']
                ]);
                return [
                    'success' => true,
                    'transaction_reference' => $data['data']['transaction_reference']
                ];
            }

            // Handle API-level errors (success: false or missing data)
            $api_error = $data['message'] ?? $data['error'] ?? __('Unknown error from payment server', 'paynecta-payment-gateway-for-woocommerce');
            $this->log_error('STK Push API error', [
                'order_id' => $order_id,
                'api_response' => $data
            ]);
            return [
                'success' => false,
                'error' => $api_error
            ];
        }

        public function check_payment_status($transaction_reference) {
            $api_url = $this->get_option('api_url');
            $api_key = $this->get_option('api_key');
            $user_email = $this->get_option('user_email');

            $endpoint = rtrim($api_url, '/') . '/payment/status';
            $url = add_query_arg('transaction_reference', $transaction_reference, $endpoint);

            $headers = [
                'X-API-Key' => $api_key,
                'X-User-Email' => $user_email,
                'Accept' => 'application/json'
            ];

            $response = wp_remote_get($url, [
                'headers' => $headers,
                'timeout' => 30
            ]);

            // Handle WP_Error (network failures, timeouts, etc.)
            if (is_wp_error($response)) {
                $error_message = $response->get_error_message();
                $this->log_error('Payment status check network error', [
                    'transaction_reference' => $transaction_reference,
                    'error' => $error_message
                ]);
                return [
                    'success' => false,
                    /* translators: %s: Error message from network */
                    'error' => sprintf(__('Connection error: %s', 'paynecta-payment-gateway-for-woocommerce'), $error_message)
                ];
            }

            // Check HTTP status code
            $http_code = wp_remote_retrieve_response_code($response);
            $body = wp_remote_retrieve_body($response);

            // Handle non-200 HTTP responses
            if ($http_code < 200 || $http_code >= 300) {
                $this->log_error('Payment status check HTTP error', [
                    'transaction_reference' => $transaction_reference,
                    'http_code' => $http_code,
                    'response_body' => $body
                ]);
                return [
                    'success' => false,
                    /* translators: %d: HTTP status code */
                    'error' => sprintf(__('API error (HTTP %d)', 'paynecta-payment-gateway-for-woocommerce'), $http_code)
                ];
            }

            // Handle JSON decode failures
            $data = json_decode($body, true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                $this->log_error('Payment status check JSON decode error', [
                    'transaction_reference' => $transaction_reference,
                    'json_error' => json_last_error_msg(),
                    'response_body' => substr($body, 0, 500)
                ]);
                return [
                    'success' => false,
                    'error' => __('Invalid response from payment server', 'paynecta-payment-gateway-for-woocommerce')
                ];
            }

            // Check for successful response
            if (isset($data['success']) && $data['success'] === true && isset($data['data'])) {
                return [
                    'success' => true,
                    'data' => $data['data']
                ];
            }

            // Handle API-level errors
            $api_error = $data['message'] ?? $data['error'] ?? __('Unable to check payment status', 'paynecta-payment-gateway-for-woocommerce');
            $this->log_error('Payment status check API error', [
                'transaction_reference' => $transaction_reference,
                'api_response' => $data
            ]);
            return [
                'success' => false,
                'error' => $api_error
            ];
        }

        public function ajax_check_payment_status() {
            try {
                // Verify nonce
                if (!isset($_POST['nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'paynecta_status_check')) {
                    wp_send_json_error(['message' => 'Invalid security token', 'error_code' => 'invalid_nonce']);
                    return;
                }

                // Sanitize inputs with proper wp_unslash
                $transaction_reference = isset($_POST['transaction_reference']) ? sanitize_text_field(wp_unslash($_POST['transaction_reference'])) : '';
                $order_id = isset($_POST['order_id']) ? absint(wp_unslash($_POST['order_id'])) : 0;

                if (empty($transaction_reference) || empty($order_id)) {
                    wp_send_json_error(['message' => 'Missing required parameters', 'error_code' => 'missing_params']);
                    return;
                }

                $order = wc_get_order($order_id);
                if (!$order) {
                    wp_send_json_error(['message' => 'Order not found', 'error_code' => 'order_not_found']);
                    return;
                }

                $status_result = $this->check_payment_status($transaction_reference);

                // Handle error responses from check_payment_status
                if (!$status_result || (isset($status_result['success']) && $status_result['success'] === false)) {
                    $error_message = isset($status_result['error']) ? $status_result['error'] : __('Unable to check payment status', 'paynecta-payment-gateway-for-woocommerce');
                    wp_send_json_error([
                        'message' => $error_message,
                        'error_code' => 'api_error',
                        'can_retry' => true
                    ]);
                    return;
                }

            // Extract the data from successful response
            $status_data = isset($status_result['data']) ? $status_result['data'] : $status_result;
            $status = $status_data['status'] ?? 'pending';
            $amount = $status_data['amount'] ?? 0;
            $mpesa_receipt = $status_data['mpesa_receipt_number'] ?? '';
            
            $current_status = $order->get_status();
            
            if ($status === 'completed' && !in_array($current_status, ['completed', 'processing'])) {
                // Prepare variables safely with type checking
                $currency_symbol = (string)get_woocommerce_currency_symbol($order->get_currency());
                $customer_name = (string)($order->get_billing_first_name() . ' ' . $order->get_billing_last_name());
                
                // Handle potentially complex amount types
                $raw_amount = isset($status_data['amount']) ? $status_data['amount'] : 0;
                if (is_array($raw_amount) || is_object($raw_amount)) {
                    $clean_amount = '0.00'; 
                } else {
                    $clean_amount = wp_strip_all_tags((string)$raw_amount);
                }

                $clean_order_id = (string)$order_id;
                
                 // Handle potentially complex receipt types
                $raw_receipt = isset($status_data['mpesa_receipt_number']) ? $status_data['mpesa_receipt_number'] : '';
                if (is_array($raw_receipt) || is_object($raw_receipt)) {
                    $clean_receipt = '';
                } else {
                    $clean_receipt = wp_strip_all_tags((string)$raw_receipt);
                }

                $clean_ref = (string)$transaction_reference;
                
                if (!empty($clean_receipt)) {
                    $order->update_meta_data('_paynecta_mpesa_receipt', $clean_receipt);
                }
                
                // Construct message safely using explicit format string
                /* translators: 1: Customer Name, 2: Currency Symbol, 3: Amount, 4: Order ID, 5: Receipt Number */
                $msg_fmt = __("Dear %1\$s, your payment of %2\$s %3\$s via Paynecta M-Pesa for order #%4\$s has been successfully received. M-Pesa Receipt: %5\$s. Thank you for your payment.", 'paynecta-payment-gateway-for-woocommerce');
                
                $customer_message = sprintf(
                    $msg_fmt,
                    $customer_name,
                    $currency_symbol,
                    $clean_amount,
                    $clean_order_id,
                    $clean_receipt
                );

                $order->set_customer_note($customer_message);

                $configured_status = $this->get_option('order_status_on_payment', 'processing');
                $allowed_statuses = ['processing', 'completed', 'on-hold'];
                
                if (!in_array($configured_status, $allowed_statuses)) {
                    $configured_status = 'processing';
                }

                if ($configured_status === 'completed') {
                    $order->payment_complete($clean_receipt);
                }

                // Log note first - simplify to avoid nested sprintf issues
                $order->add_order_note("Payment Success (API Query): " . $customer_message);

                // Update status last
                /* translators: 1: Transaction Ref, 2: Receipt, 3: Currency, 4: Amount */
                $status_fmt = __("Payment received via Paynecta M-Pesa. Transaction Ref: %1\$s, M-Pesa Receipt: %2\$s, Amount: %3\$s %4\$s", 'paynecta-payment-gateway-for-woocommerce');
                
                $status_note = sprintf(
                    $status_fmt,
                    $clean_ref,
                    $clean_receipt,
                    $currency_symbol,
                    $clean_amount
                );
                
                $order->update_status($configured_status, $status_note);
                
                $order->save();
                
                if (WC()->cart) {
                    WC()->cart->empty_cart();
                }
                
            } elseif ($status === 'cancelled' && $current_status !== 'cancelled') {
                $order->update_status('cancelled', __('Payment cancelled via Paynecta M-Pesa (API Query).', 'paynecta-payment-gateway-for-woocommerce'));
                $order->add_order_note('Payment cancelled by user (confirmed via API query)');
                $order->save();
                
            } elseif ($status === 'failed' && $current_status !== 'failed') {
                $order->update_status('failed', __('Payment failed via Paynecta M-Pesa (API Query).', 'paynecta-payment-gateway-for-woocommerce'));
                $order->add_order_note('Payment failed (confirmed via API query)');
                $order->save();
            }
            
            wp_send_json_success([
                'status' => $status,
                'status_label' => $status_data['status_label'] ?? ucfirst($status),
                'amount' => $status_data['formatted_amount'] ?? wc_price($amount),
                'mpesa_receipt' => $mpesa_receipt,
                'order_url' => $order->get_checkout_order_received_url()
            ]);
            } catch (Throwable $e) {
                $this->log_error('AJAX payment status check fatal error', [
                    'error' => $e->getMessage(),
                    'file' => $e->getFile(),
                    'line' => $e->getLine(),
                    'trace' => $e->getTraceAsString(),
                    'api_data' => isset($status_data) ? $status_data : 'Not set'
                ]);
                wp_send_json_error([
                    'message' => 'Debug Error: ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine(),
                    'error_code' => 'server_error',
                    'can_retry' => true
                ]);
            }
        }

        public function handle_payment_waiting_page() {
            // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Verification done via order key later
            if (!is_checkout() || !isset($_GET['paynecta_wait'])) {
                return;
            }

            // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Verification done via order key
            $order_id = absint($_GET['order_id'] ?? 0);
             // phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- wp_unslash used inside sanitize_text_field, nonce checked via key
            $transaction_ref = sanitize_text_field(wp_unslash($_GET['transaction_ref'] ?? ''));
             // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- This IS the verification token
            $order_key = sanitize_text_field(wp_unslash($_GET['key'] ?? ''));

            if (!$order_id || !$transaction_ref || !$order_key) {
                return;
            }

            $order = wc_get_order($order_id);
            if (!$order || $order->get_order_key() !== $order_key) {
                return;
            }

            wp_enqueue_script('paynecta-payment-waiting', plugin_dir_url(__FILE__) . 'assets/js/payment-waiting.js', ['jquery'], '1.0.0', true);
            
            wp_localize_script('paynecta-payment-waiting', 'paynecta_waiting', [
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('paynecta_status_check'),
                'order_id' => $order_id,
                'transaction_ref' => $transaction_ref,
                'phone_number' => $order->get_meta('_paynecta_phone_number'),
                'amount' => wc_price($order->get_total()),
                'order_url' => $order->get_checkout_order_received_url(),
                'checkout_url' => wc_get_checkout_url(),
                'max_polls' => 18,
                'poll_interval' => 5000,
                'messages' => [
                    'waiting_title' => __('Processing Payment', 'paynecta-payment-gateway-for-woocommerce'),
                    'waiting_text' => __('Please check your phone and enter your M-Pesa PIN to complete the payment.', 'paynecta-payment-gateway-for-woocommerce'),
                    'success_title' => __('Payment Successful!', 'paynecta-payment-gateway-for-woocommerce'),
                    'success_text' => __('Your payment has been received successfully.', 'paynecta-payment-gateway-for-woocommerce'),
                    'cancelled_title' => __('Payment Cancelled', 'paynecta-payment-gateway-for-woocommerce'),
                    'cancelled_text' => __('You cancelled the payment. You can try again.', 'paynecta-payment-gateway-for-woocommerce'),
                    'failed_title' => __('Payment Failed', 'paynecta-payment-gateway-for-woocommerce'),
                    'failed_text' => __('Payment could not be processed. Please try again.', 'paynecta-payment-gateway-for-woocommerce'),
                    'timeout_title' => __('Payment Timeout', 'paynecta-payment-gateway-for-woocommerce'),
                    'timeout_text' => __('Payment took too long. Please check your order status or try again.', 'paynecta-payment-gateway-for-woocommerce'),
                    'try_again' => __('Try Again', 'paynecta-payment-gateway-for-woocommerce'),
                    'view_order' => __('View Order', 'paynecta-payment-gateway-for-woocommerce'),
                    'cancel_payment' => __('Cancel Payment', 'paynecta-payment-gateway-for-woocommerce')
                ]
            ]);

            add_action('wp_enqueue_scripts', [$this, 'payment_waiting_styles']);
        }

        public function payment_waiting_styles() {
            wp_enqueue_style('paynecta-waiting', plugin_dir_url(__FILE__) . 'assets/css/paynecta-waiting.css', [], '1.0.0');
        }


        /**
         * Hide checkout form when in payment waiting mode
         */
        public function hide_checkout_form() {
            // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- View logic based on URL param
            if (isset($_GET['paynecta_wait']) && sanitize_text_field(wp_unslash($_GET['paynecta_wait'])) === '1') {
                echo '<div style="text-align: center; padding: 50px;">
                    <h3>Processing your payment...</h3>
                    <p>Please wait while we process your payment.</p>
                </div>';
            }

        }

        public function add_admin_menu() {
            add_menu_page(
                'Paynecta Transactions',
                'Paynecta',
                'manage_woocommerce',
                'paynecta-dashboard',
                [$this, 'dashboard_page'],
                'dashicons-money-alt',
                56
            );
        }

        public function dashboard_page() {
            // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Export link usage
            if (isset($_GET['export']) && sanitize_text_field(wp_unslash($_GET['export'])) === 'csv') {
                $this->export_transactions_csv();
                return;
            }

            $transactions = $this->get_all_transactions();
            $stats = $this->get_transaction_stats();

            ?>
            <div class="wrap">
                <h1 style="color: #0e443f;">
                    <span class="dashicons dashicons-money-alt" style="color: #0e443f;"></span>
                    Paynecta Transactions Dashboard
                </h1>

                <!-- Stats Cards -->
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin: 20px 0;">
                    <div style="background: linear-gradient(135deg, #0e443f, #1a6b5f); color: white; padding: 20px; border-radius: 10px; text-align: center;">
                        <h3 style="margin: 0; color: white;">Total Transactions</h3>
                        <p style="font-size: 24px; font-weight: bold; margin: 10px 0;"><?php echo esc_html( $stats['total'] ); ?></p>
                    </div>
                    <div style="background: linear-gradient(135deg, #27ae60, #2ecc71); color: white; padding: 20px; border-radius: 10px; text-align: center;">
                        <h3 style="margin: 0; color: white;">Successful</h3>
                        <p style="font-size: 24px; font-weight: bold; margin: 10px 0;"><?php echo esc_html( $stats['completed'] ); ?></p>
                    </div>
                    <div style="background: linear-gradient(135deg, #e74c3c, #c0392b); color: white; padding: 20px; border-radius: 10px; text-align: center;">
                        <h3 style="margin: 0; color: white;">Failed</h3>
                        <p style="font-size: 24px; font-weight: bold; margin: 10px 0;"><?php echo esc_html( $stats['failed'] ); ?></p>
                    </div>
                    <div style="background: linear-gradient(135deg, #f39c12, #e67e22); color: white; padding: 20px; border-radius: 10px; text-align: center;">
                        <h3 style="margin: 0; color: white;">Total Amount</h3>
                        <p style="font-size: 24px; font-weight: bold; margin: 10px 0;"><?php echo wp_kses_post( wc_price( $stats['total_amount'] ) ); ?></p>
                    </div>
                </div>

                <!-- Actions -->
                <div style="margin: 20px 0;">
                    <a href="<?php echo esc_url( admin_url('admin.php?page=paynecta-dashboard&export=csv') ); ?>" 
                       class="button button-secondary" style="background: #0e443f; color: white; border-color: #0e443f;">
                        <span class="dashicons dashicons-download"></span> Export CSV
                    </a>
                    <a href="<?php echo esc_url( admin_url('admin.php?page=wc-settings&tab=checkout&section=paynecta') ); ?>" 
                       class="button button-primary">
                        <span class="dashicons dashicons-admin-settings"></span> Settings
                    </a>
                </div>

                <!-- Transactions Table -->
                <div style="background: white; border: 1px solid #ddd; border-radius: 10px; overflow: hidden; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
                    <table class="wp-list-table widefat fixed striped">
                        <thead style="background: #0e443f; color: white;">
                            <tr>
                                <th style="padding: 15px; color: white;">Order ID</th>
                                <th style="padding: 15px; color: white;">Transaction Ref</th>
                                <th style="padding: 15px; color: white;">Phone Number</th>
                                <th style="padding: 15px; color: white;">Amount</th>
                                <th style="padding: 15px; color: white;">Status</th>
                                <th style="padding: 15px; color: white;">M-Pesa Receipt</th>
                                <th style="padding: 15px; color: white;">Date</th>
                                <th style="padding: 15px; color: white;">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($transactions)): ?>
                                <tr>
                                    <td colspan="8" style="text-align: center; padding: 40px; color: #666;">
                                        <span class="dashicons dashicons-info" style="font-size: 24px; color: #0e443f;"></span><br>
                                        No transactions found yet.
                                    </td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($transactions as $transaction): ?>
                                    <tr>
                                        <td style="padding: 15px;">
                                            <strong><a href="<?php echo esc_url( admin_url('post.php?post=' . $transaction['order_id'] . '&action=edit') ); ?>" 
                                                      style="color: #0e443f;">#<?php echo esc_html( $transaction['order_id'] ); ?></a></strong>
                                        </td>
                                        <td style="padding: 15px; font-family: monospace; font-size: 12px;">
                                            <?php echo esc_html( $transaction['transaction_ref'] ); ?>
                                        </td>
                                        <td style="padding: 15px;"><?php echo esc_html( $transaction['phone_number'] ); ?></td>
                                        <td style="padding: 15px; font-weight: bold;"><?php echo wp_kses_post( wc_price( $transaction['amount'] ) ); ?></td>
                                        <td style="padding: 15px;">
                                            <?php 
                                            $status_colors = [
                                                'completed' => '#27ae60',
                                                'processing' => '#3498db',
                                                'pending' => '#f39c12',
                                                'failed' => '#e74c3c',
                                                'cancelled' => '#95a5a6'
                                            ];
                                            $color = $status_colors[$transaction['status']] ?? '#666';
                                            ?>
                                            <span style="background: <?php echo esc_attr( $color ); ?>; color: white; padding: 5px 10px; border-radius: 15px; font-size: 12px; text-transform: uppercase;">
                                                <?php echo esc_html( $transaction['status'] ); ?>
                                            </span>
                                        </td>
                                        <td style="padding: 15px; font-family: monospace; font-size: 12px;">
                                            <?php echo esc_html( $transaction['mpesa_receipt'] ?: '-' ); ?>
                                        </td>
                                        <td style="padding: 15px;"><?php echo esc_html( date_i18n( 'M j, Y g:i A', strtotime( $transaction['date'] ) ) ); ?></td>
                                        <td style="padding: 15px;">
                                            <a href="<?php echo esc_url( admin_url('post.php?post=' . $transaction['order_id'] . '&action=edit') ); ?>" 
                                               class="button button-small" style="background: #0e443f; color: white; border-color: #0e443f;">
                                                View Order
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

            </div>
            <?php
        }

        private function get_all_transactions() {
            $orders = wc_get_orders([
                'payment_method' => 'paynecta',
                'limit' => -1,
                'orderby' => 'date',
                'order' => 'DESC'
            ]);

            $transactions = [];
            foreach ($orders as $order) {
                $transaction_ref = $order->get_meta('_paynecta_transaction_reference');
                $phone_number = $order->get_meta('_paynecta_phone_number');
                $mpesa_receipt = $order->get_meta('_paynecta_mpesa_receipt');
                
                if (!$mpesa_receipt) {
                    $notes = $order->get_customer_order_notes();
                    foreach ($notes as $note) {
                        if (strpos($note->comment_content, 'M-Pesa Receipt:') !== false) {
                            preg_match('/M-Pesa Receipt:\s*([A-Z0-9]+)/', $note->comment_content, $matches);
                            if (isset($matches[1])) {
                                $mpesa_receipt = $matches[1];
                                break;
                            }
                        }
                    }
                }

                $transactions[] = [
                    'order_id' => $order->get_id(),
                    'transaction_ref' => $transaction_ref ?: '-',
                    'phone_number' => $phone_number ?: $order->get_billing_phone(),
                    'amount' => $order->get_total(),
                    'status' => $order->get_status(),
                    'mpesa_receipt' => $mpesa_receipt,
                    'date' => $order->get_date_created()->date('Y-m-d H:i:s'),
                    'customer_name' => $order->get_billing_first_name() . ' ' . $order->get_billing_last_name()
                ];
            }

            return $transactions;
        }

        private function get_transaction_stats() {
            $transactions = $this->get_all_transactions();
            
            $stats = [
                'total' => count($transactions),
                'completed' => 0,
                'failed' => 0,
                'pending' => 0,
                'cancelled' => 0,
                'total_amount' => 0
            ];

            foreach ($transactions as $transaction) {
                $status = $transaction['status'];
                
                if (in_array($status, ['completed', 'processing'])) {
                    $stats['completed']++;
                    $stats['total_amount'] += $transaction['amount'];
                } elseif ($status === 'failed') {
                    $stats['failed']++;
                } elseif ($status === 'pending') {
                    $stats['pending']++;
                } elseif ($status === 'cancelled') {
                    $stats['cancelled']++;
                }
            }

            return $stats;
        }

        private function export_transactions_csv() {
            $transactions = $this->get_all_transactions();
            
            $filename = 'paynecta-transactions-' . gmdate('Y-m-d') . '.csv';
            
            header('Content-Type: text/csv');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            
            $output = fopen('php://output', 'w');
            
            fputcsv($output, [
                'Order ID',
                'Transaction Reference',
                'Customer Name',
                'Phone Number',
                'Amount',
                'Status',
                'M-Pesa Receipt',
                'Date'
            ]);
            
            foreach ($transactions as $transaction) {
                fputcsv($output, [
                    $transaction['order_id'],
                    $transaction['transaction_ref'],
                    $transaction['customer_name'],
                    $transaction['phone_number'],
                    $transaction['amount'],
                    $transaction['status'],
                    $transaction['mpesa_receipt'],
                    $transaction['date']
                ]);
            }
            
            // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- Direct output stream used for download
            fclose($output);
            exit;
        }

        public function display_transaction_reference_in_admin($order) {
            if ($order->get_payment_method() !== 'paynecta') {
                return;
            }

            $transaction_ref = $order->get_meta('_paynecta_transaction_reference');
            $phone_number = $order->get_meta('_paynecta_phone_number');
            
            if ($transaction_ref) {
                echo '<div class="address">';
                echo '<p><strong>' . esc_html__('Paynecta Transaction Reference:', 'paynecta-payment-gateway-for-woocommerce') . '</strong><br>';
                echo '<span style="font-family: monospace; background: #f0f0f0; padding: 2px 6px; border-radius: 3px;">' . esc_html($transaction_ref) . '</span></p>';
                
                if ($phone_number) {
                    echo '<p><strong>' . esc_html__('M-Pesa Phone Number:', 'paynecta-payment-gateway-for-woocommerce') . '</strong><br>';
                    echo esc_html($phone_number) . '</p>';
                }
                echo '</div>';
            }
        }

        public function display_paynecta_payment_details($order) {
            if ($order->get_payment_method() !== 'paynecta') {
                return;
            }

            $transaction_ref = $order->get_meta('_paynecta_transaction_reference');
            $phone_number = $order->get_meta('_paynecta_phone_number');
            $mpesa_receipt = $order->get_meta('_paynecta_mpesa_receipt');
            
            if (!$mpesa_receipt) {
                $notes = $order->get_customer_order_notes();
                foreach ($notes as $note) {
                    if (strpos($note->comment_content, 'M-Pesa Receipt:') !== false) {
                        preg_match('/M-Pesa Receipt:\s*([A-Z0-9]+)/', $note->comment_content, $matches);
                        if (isset($matches[1])) {
                            $mpesa_receipt = $matches[1];
                            break;
                        }
                    }
                }
            }

            if ($transaction_ref || $phone_number || $mpesa_receipt) {
                echo '<div class="order_data_column" style="clear: both; float: none; width: 100%;">';
                echo '<div class="address" style="padding: 12px; background: #f8f9fa; border: 1px solid #e9ecef; border-radius: 4px; margin-top: 12px;">';
                echo '<h3 style="margin-top: 0; color: #0e443f;">' . esc_html__('Paynecta Payment Details', 'paynecta-payment-gateway-for-woocommerce') . '</h3>';
                
                if ($transaction_ref) {
                    echo '<p><strong>' . esc_html__('Transaction Reference:', 'paynecta-payment-gateway-for-woocommerce') . '</strong><br>';
                    echo '<span style="font-family: monospace; background: #fff; padding: 4px 8px; border: 1px solid #ddd; border-radius: 3px; font-size: 12px;">' . esc_html($transaction_ref) . '</span></p>';
                }
                
                if ($phone_number) {
                    echo '<p><strong>' . esc_html__('M-Pesa Phone:', 'paynecta-payment-gateway-for-woocommerce') . '</strong><br>';
                    echo '<span style="font-family: monospace;">' . esc_html($phone_number) . '</span></p>';
                }
                
                if ($mpesa_receipt) {
                    echo '<p><strong>' . esc_html__('M-Pesa Receipt:', 'paynecta-payment-gateway-for-woocommerce') . '</strong><br>';
                    echo '<span style="font-family: monospace; background: #d4edda; padding: 4px 8px; border: 1px solid #c3e6cb; border-radius: 3px; color: #155724;">' . esc_html($mpesa_receipt) . '</span></p>';
                }
                
                echo '</div>';
                echo '</div>';
            }
        }

        public function migrate_mpesa_receipts_to_meta() {
            $orders = wc_get_orders([
                'payment_method' => 'paynecta',
                'limit' => -1,
                // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
                'meta_query' => [
                    [
                        'key' => '_paynecta_mpesa_receipt',
                        'compare' => 'NOT EXISTS'
                    ]
                ]
            ]);

            $updated_count = 0;
            foreach ($orders as $order) {
                $notes = $order->get_customer_order_notes();
                foreach ($notes as $note) {
                    if (strpos($note->comment_content, 'M-Pesa Receipt:') !== false) {
                        preg_match('/M-Pesa Receipt:\s*([A-Z0-9]+)/', $note->comment_content, $matches);
                        if (isset($matches[1])) {
                            $order->update_meta_data('_paynecta_mpesa_receipt', $matches[1]);
                            $order->save();
                            $updated_count++;
                            break;
                        }
                    }
                }
            }

            return $updated_count;
        }

        public function handle_webhook_callback() {
            $request_body = @file_get_contents('php://input');
            $json_data = json_decode($request_body, true);

            if (!$json_data || !isset($json_data['data'])) {
                wp_send_json_error(['message' => 'Invalid webhook data.'], 400);
                exit;
            }

            $webhook_data = $json_data['data'];
            $event_type = $json_data['event_type'] ?? '';
            $transaction_data = $webhook_data['transaction'] ?? [];
            
            $transaction_reference = $transaction_data['reference'] ?? '';
            
            if (empty($transaction_reference)) {
                wp_send_json_error(['message' => 'No transaction reference found.'], 400);
                exit;
            }

            $orders = wc_get_orders([
                // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
                'meta_key' => '_paynecta_transaction_reference',
                // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
                'meta_value' => $transaction_reference,
                'limit' => 1
            ]);

            if (empty($orders)) {
                wp_send_json_error(['message' => 'Order not found.'], 400);
                exit;
            }

            $order = $orders[0];
            $order_id = $order->get_id();

            $current_order_status = $order->get_status();
            if (in_array($current_order_status, ['completed', 'processing', 'failed', 'cancelled'])) {
                wp_send_json_success(['message' => 'Payment already processed.'], 200);
                exit;
            }

            $transaction_status = $transaction_data['status'] ?? '';
            $amount = $transaction_data['amount'] ?? 0;
            $phone = $webhook_data['customer']['mobile_number'] ?? '';
            $mpesa_receipt = $webhook_data['mpesa_receipt_number'] ?? '';

            $order_total = $order->get_total();
            $currency_symbol = get_woocommerce_currency_symbol($order->get_currency());

            if ($event_type === 'payment.completed' && $transaction_status === 'completed' && (float)$amount >= (float)$order_total) {
                if ($mpesa_receipt) {
                    $order->update_meta_data('_paynecta_mpesa_receipt', $mpesa_receipt);
                }
                
                $customer_message = sprintf(
                    __("Dear %1\$s, your payment of %2\$s %3\$s via Paynecta M-Pesa for order #%4\$s has been successfully received. M-Pesa Receipt: %5\$s. Thank you for your payment.", 'paynecta-payment-gateway-for-woocommerce'),
                    $order->get_billing_first_name() . ' ' . $order->get_billing_last_name(),
                    $currency_symbol,
                    $amount,
                    $order_id,
                    $mpesa_receipt
                );

                $order->set_customer_note($customer_message);

                $configured_status = $this->get_option('order_status_on_payment', 'processing');
                $allowed_statuses = ['processing', 'completed', 'on-hold'];
                
                if (!in_array($configured_status, $allowed_statuses)) {
                    $configured_status = 'processing';
                }

                if ($configured_status === 'completed') {
                    $order->payment_complete($mpesa_receipt);
                }

                $order->update_status(
                    $configured_status,
                    sprintf(
                        __("Payment received via Paynecta M-Pesa. Transaction Ref: %1\$s, M-Pesa Receipt: %2\$s, Amount: %3\$s %4\$s, Phone: %5\$s", 'paynecta-payment-gateway-for-woocommerce'),
                        $transaction_reference,
                        $mpesa_receipt,
                        $currency_symbol,
                        $amount,
                        $phone
                    )
                );

                $order->add_order_note(sprintf("Payment Success: '%s'", $customer_message));
                $order->save();

            } elseif ($event_type === 'payment.cancelled' || $transaction_status === 'cancelled') {
                $reason = $webhook_data['reason'] ?? 'Payment cancelled by user';
                $message = sprintf(
                    __("Payment cancelled for order #%1\$s. Reason: %2\$s", 'paynecta-payment-gateway-for-woocommerce'),
                    $order_id,
                    $reason
                );

                $order->update_status('cancelled', __('Payment cancelled via Paynecta M-Pesa.', 'paynecta-payment-gateway-for-woocommerce'));
                $order->add_order_note(sprintf("Payment Cancelled: '%s'", $message));
                $order->save();

            } else {
                $message = sprintf(
                    __("Payment failed for order #%1\$s. Status: %2\$s, Amount: %3\$s %4\$s", 'paynecta-payment-gateway-for-woocommerce'),
                    $order_id,
                    $transaction_status,
                    $currency_symbol,
                    $amount
                );

                $order->update_status('failed', __('Payment failed via Paynecta M-Pesa.', 'paynecta-payment-gateway-for-woocommerce'));
                $order->add_order_note(sprintf("Payment Failed: '%s'", $message));
                $order->save();
            }

            wp_send_json_success(['message' => 'Payment processed successfully'], 200);
            exit;
        }
    }

    add_filter('woocommerce_payment_gateways', 'paynecta_add_gateway');
    function paynecta_add_gateway($methods) {
        if (class_exists('Paynecta_Gateway')) {
            $methods[] = 'Paynecta_Gateway';
        }
        return $methods;
    }

    add_action('woocommerce_blocks_payment_method_type_registration', function($payment_method_registry) {
        if (class_exists('Paynecta_Blocks_Integration')) {
            $payment_method_registry->register(new Paynecta_Blocks_Integration());
        }
    });
}
