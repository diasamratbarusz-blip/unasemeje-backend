=== Paynecta Payment Gateway for WooCommerce ===
Contributors: paynecta
Tags: woocommerce, payment, mpesa, kenya, paynecta
Requires at least: 6.0
Tested up to: 6.9
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Send a payment link, clients pay via M-Pesa and funds go directly to any Kenyan bank of your choice. All payments automatically reconciled.

== Description ==

Paynecta Payment Gateway for WooCommerce allows you to accept M-Pesa payments directly on your WooCommerce store. Funds are automatically transferred to your preferred Kenyan bank account with full payment reconciliation.

**Key Features:**

* Simple integration with Paynecta payment system
* WooCommerce block checkout support
* Configurable order status on successful payment
* Webhook support for payment confirmation
* Clean and minimal codebase
* Transaction reference display in admin
* M-Pesa receipt tracking
* Payment dashboard with statistics

**Requirements:**

* WordPress 6.0+
* WooCommerce 8.4+
* PHP 7.4+
* Paynecta account (sign up at https://paynecta.co.ke/)

== External Services ==

This plugin connects to the Paynecta API to process M-Pesa payments. The connection is required for the payment functionality to work.

**What data is sent:**

* Customer's M-Pesa phone number (required to initiate the STK push payment prompt)
* Payment amount (the order total)
* Your Paynecta Payment Code (to identify your payment link)
* Transaction reference (to track the payment status)

**When data is sent:**

* When a customer initiates a payment at checkout
* When checking the payment status after a payment is initiated
* When receiving webhook callbacks for payment confirmations

**Service Provider:**

This service is provided by Paynecta Limited.

* Website: [https://paynecta.co.ke/](https://paynecta.co.ke/)
* Terms of Service: [https://paynecta.co.ke/terms](https://paynecta.co.ke/terms)
* Privacy Policy: [https://paynecta.co.ke/privacy](https://paynecta.co.ke/privacy)

== Installation ==

1. Upload the plugin files to `/wp-content/plugins/paynecta-payment-gateway-for-woocommerce/`
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to WooCommerce > Settings > Payments
4. Configure the Paynecta Payment Gateway settings

== Configuration ==

Configure the following settings in WooCommerce > Settings > Payments > Paynecta Payment Gateway:

* **API URL**: Your Paynecta API endpoint
* **Payment Code**: Your Paynecta payment link code
* **API Key**: Your Paynecta API key
* **User Email**: Your Paynecta account email
* **Order Status on Payment**: Choose what status orders should have after successful payment

== Frequently Asked Questions ==

= Do I need a Paynecta account? =

Yes, you need to sign up for a Paynecta account at https://paynecta.co.ke/ to get your API credentials.

= Which currencies are supported? =

The plugin works with Kenyan Shillings (KES) and integrates with Safaricom M-Pesa.

= Is this plugin secure? =

Yes, all transactions are processed securely through Paynecta's encrypted API endpoints.

== Screenshots ==

1. Payment gateway settings page
2. Checkout page with M-Pesa payment option
3. Payment processing screen
4. Admin order details with transaction information

== Changelog ==

= 1.0.0 =
* Initial release
* M-Pesa payment integration
* WooCommerce blocks support
* Payment dashboard
* Transaction tracking
* Webhook support

== Upgrade Notice ==

= 1.0.0 =
Initial release of Paynecta Payment Gateway for WooCommerce.
