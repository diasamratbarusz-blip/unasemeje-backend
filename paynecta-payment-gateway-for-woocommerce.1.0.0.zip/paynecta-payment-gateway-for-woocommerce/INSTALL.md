# Installation Instructions

## Paynecta Payment Gateway for WooCommerce v1.0.0

### Requirements
- WordPress 6.0 or higher
- WooCommerce 8.4 or higher
- PHP 7.4 or higher
- Paynecta account (sign up at https://paynecta.co.ke/)

### Installation Steps

#### Method 1: WordPress Admin Upload
1. Download the `paynecta-gateway.zip` file
2. Go to WordPress Admin > Plugins > Add New
3. Click "Upload Plugin"
4. Choose the downloaded zip file
5. Click "Install Now"
6. Click "Activate Plugin"

#### Method 2: Manual Installation
1. Download and extract the `paynecta-gateway.zip` file
2. Upload the `paynecta-gateway` folder to `/wp-content/plugins/`
3. Go to WordPress Admin > Plugins
4. Find "Paynecta Payment Gateway for WooCommerce" and click "Activate"

### Configuration

1. Go to **WooCommerce > Settings > Payments**
2. Find "Paynecta Payment Gateway" and click **Manage**
3. Configure the following settings:
   - **Enable**: Check to enable the gateway
   - **Title**: Payment method title (e.g., "M-Pesa Payment")
   - **Description**: Description shown to customers
   - **API URL**: `https://paynecta.co.ke/api/v1`
   - **Payment Code**: Your Paynecta payment link code (e.g., PNT_371193)
   - **API Key**: Your Paynecta API key
   - **User Email**: Your Paynecta account email
   - **Order Status**: Status to set when payment is received

4. Click **Save changes**

### Getting Paynecta Credentials

1. Visit https://paynecta.co.ke/
2. Sign up for an account
3. Complete the verification process
4. Get your Payment Code and API Key from the dashboard
5. Set up your callback URL in Paynecta dashboard

### Testing

1. Add a product to your cart
2. Go to checkout
3. Select "Paynecta Payment" (or your custom title)
4. Enter a valid M-Pesa phone number
5. Complete the test transaction

### Support

For support and questions:
- Visit: https://paynecta.co.ke/
- Email: support@paynecta.co.ke

### Troubleshooting

**Gateway not showing on checkout:**
- Ensure WooCommerce is active and updated
- Check that the gateway is enabled in settings
- Verify all required settings are configured

**Payment not processing:**
- Check your API credentials
- Ensure callback URL is set in Paynecta dashboard
- Check WordPress error logs for any issues

**Orders stuck in pending:**
- Verify webhook URL is configured correctly
- Check if payments are being received in Paynecta dashboard
- Review order notes for transaction details
