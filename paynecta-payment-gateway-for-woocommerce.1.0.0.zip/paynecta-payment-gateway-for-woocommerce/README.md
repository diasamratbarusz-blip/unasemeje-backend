# Paynecta Payment Gateway for WooCommerce

Send a payment link, clients pay via M-Pesa and funds go directly to any Kenyan bank of your choice. All payments automatically reconciled.

Visit [https://paynecta.co.ke/](https://paynecta.co.ke/) for more information.

## Features

- Simple integration with Paynecta payment system
- WooCommerce block checkout support
- Configurable order status on successful payment
- Webhook support for payment confirmation
- Clean and minimal codebase
- Transaction reference display in admin
- M-Pesa receipt tracking
- Payment dashboard with statistics

## Installation

1. Upload the plugin files to `/wp-content/plugins/paynecta-payment-gateway/`
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to WooCommerce > Settings > Payments
4. Configure the Paynecta Payment Gateway settings

## Configuration

Configure the following settings in WooCommerce > Settings > Payments > Paynecta Payment Gateway:

- **API URL**: Your Paynecta API endpoint
- **Payment Code**: Your Paynecta payment link code
- **API Key**: Your Paynecta API key
- **User Email**: Your Paynecta account email
- **Order Status on Payment**: Choose what status orders should have after successful payment

## Requirements

- WordPress 6.0+
- WooCommerce 8.4+
- PHP 7.4+

## License

GPL-2.0+
